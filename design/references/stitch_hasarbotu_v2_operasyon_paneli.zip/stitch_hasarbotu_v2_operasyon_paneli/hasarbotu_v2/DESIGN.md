---
name: HasarBotu V2
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1b1b1e'
  surface-container: '#1f1f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e4e1e5'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#e4e1e5'
  inverse-on-surface: '#303033'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#c8c6c8'
  on-secondary: '#303032'
  secondary-container: '#474649'
  on-secondary-container: '#b7b4b7'
  tertiary: '#ffb596'
  on-tertiary: '#581e00'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#e4e2e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#131316'
  on-background: '#e4e1e5'
  surface-variant: '#353438'
typography:
  page-title:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  plate-id:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: 0.05em
  section-header:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  table-cell:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  gutter: 12px
  margin: 16px
  component-padding-x: 12px
  component-padding-y: 6px
---

## Brand & Style
The design system is engineered for high-utility, technical environments within the Turkish insurance expertise sector. It prioritizes information density and logical structure over decorative flair. The style is **Modern Functionalist**, drawing inspiration from professional enterprise CAD and ERP software. It evokes a sense of precision, speed, and authoritative reliability.

The aesthetic is characterized by:
- **Utilitarian Precision:** Every pixel serves a functional purpose.
- **Structural Rigidity:** Clear boundaries and high-contrast divisions between workspace modules.
- **Technical Sophistication:** A "pro-tool" feel that respects the expertise of the user, avoiding any soft or "consumer-friendly" tropes.

## Colors
The color architecture is built for prolonged focus and visual hierarchy in data-heavy screens. 

**Dark Theme (Default):**
- **Base:** True Black (#0D0D0E) for the application backdrop.
- **Panels:** #171719 for secondary sidebars and navigation backgrounds.
- **Surfaces:** #212124 for primary data cards and input backgrounds.
- **Borders:** #303033 for subtle separation.

**Light Theme:**
- **Base:** #F3F4F6 (Neutral Gray) for the workspace.
- **Surfaces:** #FFFFFF (White) for active content modules.
- **Borders:** #E5E7EB.

**Accent & Semantic:**
The Primary Blue (#2563EB) is used strictly for primary actions and active state indicators. Semantic colors follow international standards for insurance risk assessment, utilizing high-chroma values to ensure they are immediately legible against the dark neutral base.

## Typography
This design system utilizes **Inter** for all UI elements to maintain a neutral, highly legible sans-serif foundation. **JetBrains Mono** is introduced specifically for vehicle license plates (Plaka) and VIN numbers to emphasize technical accuracy and distinguish identity data from descriptive text.

- **Vertical Rhythm:** Line heights are kept tight (1.2x to 1.4x) to support high-density data tables and forms.
- **Case Usage:** Section headers use Title Case. Labels for data fields should use Sentence case for improved scanning.
- **Plate Identity:** Should always be rendered in uppercase JetBrains Mono with slight tracking to mimic physical license plate aesthetics.

## Layout & Spacing
The layout is designed for a **1600x1000px primary canvas**, utilizing a fluid-width body with fixed-width sidebars (typically 240px for navigation and 320px for detail inspectors).

- **Density:** The system uses a 4px baseline grid. Padding is intentionally minimized to allow more information to be visible without scrolling.
- **Grid:** A 12-column grid is used for dashboard layouts, while table-heavy views use a simple vertical stack with collapsible sections.
- **Breakpoints:** 
  - Desktop: 1440px+ (Full 12-column layout)
  - Compact: 1024px - 1439px (Sidebar collapses to icons)
  - Below 1024px is not supported for the primary expertise interface.

## Elevation & Depth
In alignment with the Windows-style functionalist approach, depth is conveyed through **Tonal Layering** rather than shadows.

- **Level 0 (Background):** #0D0D0E (Dark) / #F3F4F6 (Light).
- **Level 1 (Panels/Sidebar):** Slightly lighter than background.
- **Level 2 (Cards/Content):** Lighter still.
- **Depth Indicators:** 1px solid borders are preferred over shadows. Shadows are used exclusively for **Modals** and **Context Menus** to provide a clear focus layer, using a sharp, low-spread 8px shadow with 40% opacity.
- **State Indicators:** Hover states utilize a subtle 5% white overlay (in dark mode) or 5% black overlay (in light mode).

## Shapes
Shapes are geometric and disciplined. Rounded corners are used sparingly to prevent the UI from appearing "soft."

- **Inputs & Buttons:** 6px radius for a modern but crisp appearance.
- **Cards & Data Containers:** 8px radius for structural containment.
- **Modals & Dialogs:** 10px radius to distinguish floating system-level elements.
- **Status Pills:** 4px radius (not pill-shaped) to maintain the "blocky" technical aesthetic.

## Components
- **Buttons:** High-contrast solid fills for primary actions. Secondary actions use an outlined style with 1px borders. Tertiary actions (e.g., "Cancel") are ghost-style with no border until hover.
- **Inputs:** Backgrounds should be #171719 (Dark) with a 1px border. The focus state must use the Primary Blue border with a subtle 2px glow.
- **Data Tables:** High-density with 32px row heights. Use alternating row zebra-striping (2% opacity difference). Headers must be sticky with a distinct #303033 bottom border.
- **Status Chips:** Small, rectangular indicators with a subtle background tint and a high-contrast dot or border of the semantic color (e.g., "Onaylandı", "Riskli").
- **Expertise Cards:** Complex cards containing vehicle details. Use a 2-column key-value layout for metadata within the card.
- **Plate Display:** A specialized component with a white background, black text, and a blue Turkish (TR) strip on the left, using JetBrains Mono.