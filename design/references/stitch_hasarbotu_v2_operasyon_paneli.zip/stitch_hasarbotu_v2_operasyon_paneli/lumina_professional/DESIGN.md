---
name: Lumina Professional
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#4d556b'
  on-tertiary: '#ffffff'
  tertiary-container: '#656d84'
  on-tertiary-container: '#eef0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  code-label:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-max: 1440px
  gutter: 16px
---

## Brand & Style

The design system for the HasarBotu V2 Light Theme transition focuses on high-efficiency data processing and administrative clarity. Moving from a dark interface to a light one, the brand personality shifts from "stealth and focus" to "transparency and precision." 

The target audience consists of insurance professionals and data analysts who require a desktop environment that remains comfortable during extended use. The style is a hybrid of **Corporate Modern** and **Minimalism**, prioritizing content legibility and logical grouping over decorative elements. It maintains the seriousness of a Windows native application while utilizing modern spacing and subtle depth to guide the user's eye.

## Colors

This design system utilizes a high-contrast palette optimized for professional environments. 

- **Primary (#2563EB):** A vibrant, high-contrast blue used for primary actions, active states, and critical brand touchpoints.
- **Surface (#F8FAFC):** The foundational background color, chosen to reduce eye strain compared to pure white, while maintaining a clean, "light" aesthetic.
- **Text Primary (#0F172A):** A deep navy-black used for headers and primary body text to ensure maximum readability.
- **Text Secondary (#64748B):** A muted slate for labels, hints, and deactivated states.
- **Accents:** Semantic colors for status (Success: #10B981, Error: #EF4444, Warning: #F59E0B) are adjusted for higher saturation to stand out against the light background.

## Typography

The typography system relies on **Inter** for its exceptional legibility in dense UI layouts and technical interfaces. For data-heavy segments and system status labels, **JetBrains Mono** is introduced to provide a distinct visual anchor for technical information.

- **Headlines:** Use tight letter spacing and bold weights to establish a clear hierarchy.
- **Body:** Standardized at 14px for optimal information density on desktop screens.
- **Data Tables:** Use `body-sm` for row content to allow for more vertical data visibility.
- **Case IDs:** Always rendered in `code-label` to distinguish unique identifiers from prose.

## Layout & Spacing

This design system follows a **Fixed-Fluid Hybrid** model. The sidebar remains fixed at 260px, while the main content area utilizes a fluid grid that expands up to 1440px.

- **Rhythm:** A 4px baseline grid ensures consistent vertical alignment.
- **Desktop Grid:** A 12-column system is used for complex data forms, with 16px gutters to maintain a compact, professional density.
- **Padding:** Main containers use 24px (lg) padding, while internal card elements use 16px (md) to maintain a sense of structural integrity without wasting screen real estate.

## Elevation & Depth

To replace the "True Black" depth model, this design system uses **Tonal Layering** combined with **Low-Contrast Outlines**.

- **Level 0 (Background):** #F8FAFC (Slate 50) - The canvas.
- **Level 1 (Cards/Containers):** #FFFFFF (Pure White) - Used for primary content areas. These elements feature a subtle 1px border (#E2E8F0) and a very soft, transparent shadow (4px blur, 2% opacity) to provide lift.
- **Level 2 (Modals/Popovers):** #FFFFFF with a more pronounced shadow (12px blur, 8% opacity) to create a clear "floating" effect above the workspace.
- **Separators:** 1px solid lines using #F1F5F9 are used for list items to maintain structure without visual clutter.

## Shapes

The shape language is conservative and geometric to reflect the "Windows Desktop" seriousness.

- **Standard Elements:** Buttons, input fields, and small cards use a 4px (Soft) radius.
- **Large Containers:** Main content panels use 8px (rounded-lg) to subtly soften the edges of the application window.
- **Interactive States:** Hover states on list items use the same 4px radius, creating a "pill" highlight effect when selected.

## Components

### Buttons
- **Primary:** Solid #2563EB with White text. Subtle inner-glow on top edge for a tactile feel.
- **Secondary:** Ghost style with #2563EB border and text. On hover, fills with a light #EFF6FF tint.
- **Action Icons:** Transparent backgrounds, turning to #F1F5F9 on hover.

### Input Fields
- **Default:** White background with #CBD5E1 border.
- **Focus:** Border changes to #2563EB with a 2px "halo" of the same color at 10% opacity.
- **Labels:** Always positioned above the field using `code-label` typography for a technical, organized look.

### Data Tables
- **Headers:** #F1F5F9 background, bold `body-sm` text.
- **Rows:** Alternating "Zebra" striping is avoided; instead, use a subtle 1px bottom border. Hover state highlights the entire row with #F8FAFC.

### Cards
- Standard cards use white backgrounds and a single-pixel border. For "Active" or "Highlighted" cases, the left border is thickened to 4px using the Primary Blue color.

### Status Chips
- Small, uppercase text with a low-saturation background (e.g., Success chip: #DCFCE7 background, #166534 text). This ensures high legibility without being distracting.